<?php
define('DB_Database', 'findme');
define('DB_User', 'admin');
define('DB_Password', 'allieverwantedwas100%');
define('DB_Hostname', 'findme.ck6yufi1s8zs.us-east-1.rds.amazonaws.com:3306');

define('SELECT_ALL', 'Select * from findme.Events;');

?>